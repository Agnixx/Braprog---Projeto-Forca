#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>


#define MAX_TENTATIVAS 6

//Cria a estrutura da forca e realiza o teste lógico para desenhar as partes do boneco conforme erro do usuário.
void desenhar_boneco(int erros) {
    printf("\n");
    printf("  ___\n");
    printf("  |     |\n");
    printf("  |     %c\n", (erros > 0) ? 'O' : ' ');
    printf("  |    %c%c%c\n", (erros > 2) ? '/' : ' ', (erros > 1) ? '|' : ' ', (erros > 3) ? '\\' : ' ');
    printf("  |    %c %c\n", (erros > 4) ? '/' : ' ', (erros > 5) ? '\\' : ' ');
    printf("  |\n");
    printf("|\n\n");
}
//boneco vai jogar no vasco se o usuário perder
void explodir_boneco() 
{
    char *explosao[] = {
        "  ___\n"
        "  |     |\n"
        "  |    BOOM!\n"
        "  |    \\ | /\n"
        "  |     - O -\n"
        "  |    / | \\\n"
        "|\n",
        
        "  ___\n"
        "  |     |\n"
        "  |     \\ / \n"
        "  |     - * -\n"
        "  |     / \\ \n"
        "  |\n"
        "|\n",
        
        "  ___\n"
        "  |     |\n"
        "  |    \\   / \n"
        "  |    -- * --\n"
        "  |    /   \\ \n"
        "  |\n"
        "|\n",

        "  ___\n"
        "  |     |\n"
        "  |    \\       /\n"
        "  |    --     *     --\n"
        "  |    /       \\ \n"
        "  |\n"
        "|\n",

        "  ___\n"
        "  |     |\n"
        "  |    *           *\n"
        "  |   *      *      *\n"
        "  |    *           *\n"
        "  |\n"
        "|\n"
    };

    for (int i = 0; i < 5; i++) {
        system("clear"); // Para limpar o console (use "cls" se estiver no Windows)
        printf("%s", explosao[i]);
        usleep(500000);  // Espera 500 milissegundos (0,5 segundos)
    }

}


//função para exibir as letras disponíveis
void exibir_alfabeto(char alfabeto[]) {
    printf("Letras disponíveis: ");
    for (int i = 0; i < 26; i++) {
        if (alfabeto[i] != ' ') {
            printf("%c ", alfabeto[i]);
        }
    }
    printf("\n");
}

//Função para, ao fim do jogo, apresentar a função de continuar ou não.
int deseja_recomecar() {
    char resposta;
    printf("Deseja jogar novamente? (s/n): ");
    scanf(" %c", &resposta);
    return (tolower(resposta) == 's');
}

//Utilizamos matriz para separar os temas e suas respectivas palavras.
int main() {
    const char *temas[4][9] = {
        {"Melancia", "Laranja", "Limao", "Tangerina", "Melao", "Banana", "Kiwi", "Tomate", "Caqui"},
        {"Vermelho", "Azul", "Verde", "Amarelo", "Roxo", "Laranja", "Preto", "Branco", "Rosa"},
        {"Elefante", "Leao", "Gato", "Cachorro", "Tigre", "Girafa", "Jacare", "Golfinho", "Zebra"},
        {"Brasil", "Canada", "Japao", "Alemanha", "Franca", "Australia", "Mexico", "Italia", "India"}
    };

//Aqui realizamos um sistema de relacionar números com temas e palavras dentro da matriz. Por exemplo: se a pessoa escolher o tema 2 (Cores) e posteriormente escolher o número 4, a palavra escolhida sera a da posição a2,4 (amarelo).
    do {
         int tema, palavra;
        printf("\nEscolha um tema:\n 1. Frutas \n 2. Cores \n 3. Animais \n 4. Países\n");
        scanf("%d", &tema);
        tema--;

        printf("Escolha um número de 1 a 9: \n");
        scanf("%d", &palavra);
        palavra--;

//nesse caso o ponteiro *palavra_secreta irá percorrer a matriz em busca da palavra escolhida (tipo char)
        const char *palavra_secreta = temas[tema][palavra];

//essa variável usa a função strlen que retorna a quantidade de caracteres presente na variável char palavra_secreta
        int tamanho = strlen(palavra_secreta);

//limita o tamanho da palavra_exibida para 20 caracteres
        char palavra_exibida[20];
        for (int i = 0; i < tamanho; i++) palavra_exibida[i] = '_';
        palavra_exibida[tamanho] = '\0';

//cria a variável char de alfabeto
        char alfabeto[27] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        char letras_digitadas[26] = {0};

        int letras_usadas = 0, letras_encontradas = 0;

        int tentativas_restantes = MAX_TENTATIVAS;




        while (tentativas_restantes > 0 && letras_encontradas < tamanho) {
            desenhar_boneco(MAX_TENTATIVAS - tentativas_restantes);
            printf("%s\n", palavra_exibida);
            printf("Tentativas restantes: %d\n", tentativas_restantes);
            exibir_alfabeto(alfabeto);
            
//verifica o input do usuário (letra)
            char digitada;
            printf("Digite uma letra: ");
            scanf(" %c", &digitada);
            digitada = toupper(digitada);

//verificação binária para inutilizar letrar já usadas > Letra não usada = 0, letra usada = 1
            int ja_usada = 0;
            for (int i = 0; i < letras_usadas; i++) {
                if (letras_digitadas[i] == digitada) {
                    ja_usada = 1;
                    break;
                }
            }

            if (ja_usada) {
                printf("Você já digitou a letra '%c'. Tente novamente.\n", digitada);
                continue;
            }

            letras_digitadas[letras_usadas++] = digitada;
            alfabeto[digitada - 'A'] = ' ';

            int acertou = 0;
            for (int i = 0; i < tamanho; i++) {
                if (toupper(palavra_secreta[i]) == digitada) {
                    palavra_exibida[i] = palavra_secreta[i];
                    letras_encontradas++;
                    acertou = 1;
                }
            }

            if (!acertou) {
                tentativas_restantes--;
                printf("A letra '%c' não está na palavra.\n", digitada);
            } else {
                printf("Boa! A letra '%c' está na palavra.\n", digitada);
            }
        }

        desenhar_boneco(MAX_TENTATIVAS - tentativas_restantes);
        if (letras_encontradas == tamanho) {
            printf("\nParabéns! Você acertou a palavra: %s\n", palavra_secreta);
        } else {
            explodir_boneco(); //chama a animação de explosão do boneco
            printf("\nVocê perdeu e o boneco explodiu por sua culpa! A palavra era: %s\n", palavra_secreta);
        }

    } while (deseja_recomecar());

    return 0;
}